#!/usr/bin/env python3
"""Transaction and exact-source controls for the v2.3 applicator.

Usage:
  python3 APPLY-TRANSACTION-SELFTEST.py /path/to/exact/DWC2-source-tree

The reference tree is copied into disposable directories. The reference itself
is never modified.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
APPLY = HERE / 'apply_to_repo.py'
CANON = HERE / 'files' / 'r1a-device' / 'r1a_ffs_out_v2.c'
EXPECTED_ROOT_TREE = 'd3d13da79d5508d851e995be75e6016c41d3fc42'
EXPECTED_BASELINE_TREE = '223dd3983955393a9cadcbbf525767ce9a49f459'
INTENDED = {
    'r1a-device/r1a_ffs_out_v2.c',
    'r1a-device/legacy/r1a_ffs_out_v2.c.pre-holder',
    'r1a-device/README.md',
    'holder_log_guard.py',
    'holder_log_guard_selftest.py',
    'holder_roundtrip.py',
    'verify_archive_tracking.py',
    'docs/NEXT-EPOCH-HOLDER-MERGER.md',
    'verify_holder_contract_selftest.py',
    'VERIFY-REPOSITORY.sh',
}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def file_state(root: Path):
    out = {}
    for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = sorted(d for d in dirs if not (Path(base) / d).is_symlink() and d != '.git')
        for name in sorted(files):
            p = Path(base) / name
            rel = p.relative_to(root).as_posix()
            if rel.startswith('.git/') or rel == '.git':
                continue
            st = p.lstat()
            mode = stat.S_IMODE(st.st_mode)
            if p.is_symlink():
                out[rel] = ('L', mode, os.readlink(p))
            elif p.is_file():
                out[rel] = ('F', mode, sha(p))
    return out


def tree_digest(root: Path) -> str:
    h = hashlib.sha256()
    for rel, value in sorted(file_state(root).items()):
        h.update(repr((rel, value)).encode() + b'\n')
    return h.hexdigest()


def copy_ref(ref: Path):
    td = Path(tempfile.mkdtemp(prefix='r1a-v23-selftest-'))
    root = td / 'DWC2'
    shutil.copytree(ref, root, symlinks=True, copy_function=shutil.copy2,
                    ignore=shutil.ignore_patterns('.git'))
    return td, root


def run_apply(root: Path, *extra):
    return subprocess.run([sys.executable, str(APPLY), str(root), *extra],
                          text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT)


def run_gate(root: Path):
    return subprocess.run([str(root / 'VERIFY-REPOSITORY.sh')], cwd=root,
                          text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT,
                          env={**os.environ,
                               'PATH': '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'})


def require(ok, msg, out=''):
    if not ok:
        raise AssertionError(msg + ('\n' + out if out else ''))


def changed_paths(before, after):
    keys = set(before) | set(after)
    return {k for k in keys if before.get(k) != after.get(k)}


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    ref = Path(sys.argv[1]).resolve()
    if not (ref / 'baseline/pipeline/holder_merge.py').is_file():
        print('reference tree is not the expected DWC2 source tree')
        return 2

    # Import the applicator only after argument validation so this test uses the
    # exact same Git-tree implementation as production admission.
    import importlib.util
    spec = importlib.util.spec_from_file_location('v23apply', APPLY)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    require(mod.git_tree_oid(ref, omit_root_git=True) == EXPECTED_ROOT_TREE,
            'reference root Git tree is not the pinned source tree')
    require(mod.git_tree_oid(ref / 'baseline', omit_root_git=False) == EXPECTED_BASELINE_TREE,
            'reference baseline Git tree is not the pinned subtree')

    passed = 0

    # 1. Exact source preflight executes the real staged repository gate and is read-only.
    td, root = copy_ref(ref)
    try:
        before = tree_digest(root)
        p = run_apply(root, '--preflight-only')
        require(p.returncode == 0 and 'SOURCE_TREE_IDENTITY: PASS' in p.stdout and
                'PRECOMMIT_GATE: PASS' in p.stdout and 'PREFLIGHT_ONLY: PASS' in p.stdout,
                'exact-source preflight did not pass', p.stdout)
        require(tree_digest(root) == before, 'preflight-only modified the target', p.stdout)
        print('ok  exact source --preflight-only -> PASS, target unchanged')
        passed += 1
    finally:
        shutil.rmtree(td)

    # 2. Extra untracked-looking content is still source-tree drift.
    td, root = copy_ref(ref)
    try:
        (root / 'EXTRA.txt').write_text('not in source tree\n')
        before = tree_digest(root)
        p = run_apply(root)
        require(p.returncode != 0 and 'source Git tree mismatch' in p.stdout,
                'extra path was not rejected', p.stdout)
        require(tree_digest(root) == before, 'extra-path denial modified target', p.stdout)
        print('ok  extra path -> REFUSED by exact source tree, unchanged')
        passed += 1
    finally:
        shutil.rmtree(td)

    # 3. Executable-bit drift is part of Git tree identity, not just bytes.
    td, root = copy_ref(ref)
    try:
        rp = root / 'r1a-device/README.md'
        rp.chmod(rp.stat().st_mode | stat.S_IXUSR)
        before = tree_digest(root)
        p = run_apply(root)
        require(p.returncode != 0 and 'source Git tree mismatch' in p.stdout,
                'mode drift was not rejected', p.stdout)
        require(tree_digest(root) == before, 'mode-drift denial modified target', p.stdout)
        print('ok  file-mode drift -> REFUSED by exact source tree, unchanged')
        passed += 1
    finally:
        shutil.rmtree(td)

    # 4. A single baseline byte drift is a definitive pre-write deny.
    td, root = copy_ref(ref)
    try:
        q = root / 'baseline/pipeline/holder_merge.py'
        q.write_bytes(q.read_bytes() + b'\n# drift\n')
        before = tree_digest(root)
        p = run_apply(root)
        require(p.returncode != 0 and 'source Git tree mismatch' in p.stdout,
                'baseline drift was not rejected', p.stdout)
        require(tree_digest(root) == before, 'baseline-drift denial modified target', p.stdout)
        print('ok  baseline byte drift -> REFUSED before staging/commit, unchanged')
        passed += 1
    finally:
        shutil.rmtree(td)

    # 5. Commit from exact source changes exactly the intended files, preserves baseline,
    #    and the post-commit repository gate passes directly without .git.
    td, root = copy_ref(ref)
    try:
        before = file_state(root)
        baseline_before = tree_digest(root / 'baseline')
        p = run_apply(root)
        require(p.returncode == 0 and 'COMMIT: PASS' in p.stdout,
                'exact-source commit did not pass', p.stdout)
        after = file_state(root)
        require(changed_paths(before, after) == INTENDED,
                'commit changed paths outside the intended set:\n' +
                '\n'.join(sorted(changed_paths(before, after) ^ INTENDED)), p.stdout)
        require(tree_digest(root / 'baseline') == baseline_before,
                'baseline changed during successful commit')
        require(sha(root / 'r1a-device/r1a_ffs_out_v2.c') == sha(CANON),
                'canonical producer bytes differ after commit')
        g = run_gate(root)
        require(g.returncode == 0 and 'archive_tracking_proof' in g.stdout and
                'REPOSITORY_GATE: PASS' in g.stdout,
                'post-commit gate did not pass in archive/no-.git mode', g.stdout)
        print('ok  exact commit -> intended paths only, baseline unchanged, direct gate PASS')
        passed += 1

        # 6. The exact source preimage is single-use; a second application is denied.
        after_first = tree_digest(root)
        p2 = run_apply(root)
        require(p2.returncode != 0 and 'source Git tree mismatch' in p2.stdout,
                'second application was not refused', p2.stdout)
        require(tree_digest(root) == after_first, 'second application modified target', p2.stdout)
        print('ok  second application -> REFUSED by source preimage, unchanged')
        passed += 1

        # 7. Post-commit baseline drift kills the direct repository gate.
        q = root / 'baseline/pipeline/holder_merge.py'
        saved = q.read_bytes()
        q.write_bytes(saved + b'\n# post-commit drift\n')
        g2 = run_gate(root)
        require(g2.returncode != 0 and 'REPOSITORY_GATE: FAIL' in g2.stdout,
                'post-commit baseline drift did not kill gate', g2.stdout)
        q.write_bytes(saved)
        print('ok  post-commit baseline drift -> repository gate FAIL')
        passed += 1

        # 8. Canonical ignore policy is load-bearing for archive tracking proof.
        gi = root / '.gitignore'
        saved_gi = gi.read_bytes()
        gi.write_bytes(saved_gi + b'\nbaseline/**\n')
        g3 = run_gate(root)
        require(g3.returncode != 0 and 'git_tracking_check_available' in g3.stdout and
                'ARCHIVE_TRACKING_PROOF: FAIL' in g3.stdout,
                '.gitignore drift did not kill archive tracking proof', g3.stdout)
        gi.write_bytes(saved_gi)
        g4 = run_gate(root)
        require(g4.returncode == 0 and 'REPOSITORY_GATE: PASS' in g4.stdout,
                'gate did not recover after restoring canonical ignore policy', g4.stdout)
        print('ok  .gitignore drift -> archive tracking FAIL; restore -> PASS')
        passed += 1
    finally:
        shutil.rmtree(td)

    print(f'APPLY_TRANSACTION_SELFTEST: PASS {passed}/8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
