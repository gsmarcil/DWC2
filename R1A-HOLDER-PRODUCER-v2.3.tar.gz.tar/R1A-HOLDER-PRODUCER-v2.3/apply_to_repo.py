#!/usr/bin/env python3
"""Stage, verify, then apply the holder-producer delivery to a DWC2 checkout.

This delivery is bound to the exact source Git tree recovered from the supplied
DWC2 archive and independently matched to commit
9df7b1a4f91a10ef575daa4a658a69ec5ce5723f. It proves, before any target write:

  * the complete filesystem tree (excluding repository metadata .git) is the
    pinned source Git tree d3d13da79d5508d851e995be75e6016c41d3fc42;
  * the pre-holder producer and README are exact pinned preimages;
  * every textual edit has exactly one preimage anchor;
  * the complete repository gate passes on a private staging copy;
  * baseline/ is byte-identical before and after that staged gate; and
  * the live tree is unchanged between preflight and commit.

For archive checkouts without .git, the staged repository gate uses the delivered
archive tracking proof: baseline/ must equal the Git subtree tracked by the source
commit and the canonical ignore policy must not ignore any pinned baseline path.

No target byte is written before PRECOMMIT_GATE passes.  --preflight-only runs
all checks, including the staged repository gate, and then exits without a
commit.

Usage:
  python3 apply_to_repo.py /path/to/DWC2 [--preflight-only]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = HERE / 'files'
SENTINELS = HERE / 'BASELINE-SENTINELS.sha256'
LEGACY_SHA = ('83ea60d3566617eefc0a1b488c2916c0482781b57156d4f0d'
              '6116958f126118e')
SOURCE_COMMIT = '9df7b1a4f91a10ef575daa4a658a69ec5ce5723f'
SOURCE_ROOT_TREE = 'd3d13da79d5508d851e995be75e6016c41d3fc42'
SOURCE_BASELINE_TREE = '223dd3983955393a9cadcbbf525767ce9a49f459'
README_PREIMAGE_SHA = '69a3149673601cd2aafc050f7eac1363db5dc79f230a18a35b83977c8aaa0b2d'

# Existing path replaced by the canonical producer.
REPLACE_SOURCE = 'r1a-device/r1a_ffs_out_v2.c'

# These paths must not exist before application.
NEW_PATHS = [
    'r1a-device/legacy/r1a_ffs_out_v2.c.pre-holder',
    'holder_log_guard.py',
    'holder_log_guard_selftest.py',
    'holder_roundtrip.py',
    'verify_archive_tracking.py',
    'docs/NEXT-EPOCH-HOLDER-MERGER.md',
]

SELFTEST_EDITS = [
    ('CURRENT_PRODUCER = ROOT / "r1a-device" / "r1a_ffs_out_v2.c"\n',
     '''CANONICAL_PRODUCER = ROOT / "r1a-device" / "r1a_ffs_out_v2.c"

# The pre-holder source, kept as bytes rather than as a sentence.  This control
# has to keep working after the canonical producer becomes compatible, so it is
# bound to a file that never changes instead of to whatever currently occupies
# the canonical path.  Its identity is asserted below: a fixture that drifted
# would still fail closed, but it would no longer be the source it claims.
LEGACY_PRODUCER = ROOT / "r1a-device" / "legacy" / "r1a_ffs_out_v2.c.pre-holder"
LEGACY_SHA256 = ("83ea60d3566617eefc0a1b488c2916c0482781b57156d4f0d"
                 "6116958f126118e")
'''),
    ('import subprocess\nimport sys',
     'import hashlib\nimport subprocess\nimport sys'),
    ('''        inactive_result = run("--validator", str(inactive),
                              "--producer", str(CURRENT_PRODUCER))''',
     '''        inactive_result = run("--validator", str(inactive),
                              "--producer", str(LEGACY_PRODUCER))'''),
    ('''        current = run("--producer", str(CURRENT_PRODUCER))
        require(current.returncode == 1 and
                "HOLDER_PRODUCER_CONTRACT: INCOMPATIBLE" in current.stdout,
                "current legacy producer did not produce the expected closure artifact",
                current)

    print("HOLDER_CONTRACT_SELFTEST: PASS (1 positive, 9 fail-closed controls)")''',
     '''        require(LEGACY_PRODUCER.is_file(),
                f"the preserved pre-holder source is missing: {LEGACY_PRODUCER}")
        require(hashlib.sha256(LEGACY_PRODUCER.read_bytes()).hexdigest()
                == LEGACY_SHA256,
                "the preserved pre-holder source is no longer the source whose "
                "incompatibility this control asserts")
        legacy = run("--producer", str(LEGACY_PRODUCER))
        require(legacy.returncode == 1 and
                "HOLDER_PRODUCER_CONTRACT: INCOMPATIBLE" in legacy.stdout,
                "preserved pre-holder producer did not produce the expected "
                "closure artifact", legacy)

        canonical = run("--producer", str(CANONICAL_PRODUCER))
        require(canonical.returncode == 0 and
                "HOLDER_PRODUCER_CONTRACT: PASS" in canonical.stdout,
                "the canonical producer in the repository is not accepted by "
                "the checker", canonical)

    print("HOLDER_CONTRACT_SELFTEST: PASS "
          "(2 positive, 10 fail-closed controls)")'''),
]

GATE_EDITS = [
    ('''set -u

ROOT=''',
     '''set -u

# The repository gate must be read-only with respect to its own evidence tree.
# Python bytecode caches would change the archive Git-tree identity merely by
# running verification, so suppress them inside the gate rather than relying on
# the caller's environment.
PYTHONDONTWRITEBYTECODE=1
export PYTHONDONTWRITEBYTECODE

ROOT='''),
    ('''    else
        failmsg git_tracking_check_available
    fi
fi''',
     '''    else
        # GitHub source archives intentionally omit .git.  Do not convert that
        # packaging fact into an integrity bypass: require an archive-native
        # proof bound to the exact tracked baseline subtree and ignore policy.
        archive_tmp=${TMPDIR:-/tmp}/dwc2-archive-tracking.$$
        if [ -f verify_archive_tracking.py ] && \
           python3 verify_archive_tracking.py "$ROOT" >"$archive_tmp" 2>&1; then
            pass baseline_pins_tracked
            pass baseline_pins_not_ignored
            pass archive_tracking_proof
        else
            failmsg git_tracking_check_available
            [ -s "$archive_tmp" ] && sed 's/^/  /' "$archive_tmp" >&2
        fi
        rm -f "$archive_tmp"
    fi
fi'''),
    ('''rm -f "$holder_tmp"

if [ "$baseline_fail" -eq 0 ]; then''',
     '''rm -f "$holder_tmp"

# A checker nobody runs is a checker that can rot, and a discriminating control
# that is only listed in a document is not executable.  These are mandatory.
# holder_roundtrip.py builds the producer from source, so a C compiler is now a
# gate requirement; without one it reports "cannot run" and this fails.
for spec in \\
    'holder_contract_selftest:verify_holder_contract_selftest.py' \\
    'holder_log_guard_selftest:holder_log_guard_selftest.py' \\
    'holder_roundtrip:holder_roundtrip.py'
do
    label=${spec%%:*}
    script=${spec#*:}
    if [ ! -f "$script" ]; then
        failmsg "$label"
        printf '  missing: %s\\n' "$script" >&2
        holder_fail=1
        continue
    fi
    ctl_tmp=${TMPDIR:-/tmp}/dwc2-$label.$$
    if python3 "$script" >"$ctl_tmp" 2>&1; then
        pass "$label"
    else
        failmsg "$label"
        sed 's/^/  /' "$ctl_tmp" >&2
        holder_fail=1
    fi
    rm -f "$ctl_tmp"
done

if [ "$baseline_fail" -eq 0 ]; then'''),
]

PATCHES = [
    ('verify_holder_contract_selftest.py', SELFTEST_EDITS),
    ('VERIFY-REPOSITORY.sh', GATE_EDITS),
]

INTENDED_PATHS = [REPLACE_SOURCE, *NEW_PATHS,
                  *(name for name, _ in PATCHES), 'r1a-device/README.md']


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _git_obj_hash(kind: bytes, data: bytes) -> bytes:
    header = kind + b' ' + str(len(data)).encode('ascii') + b'\0'
    return hashlib.sha1(header + data).digest()


def _git_entry_cmp(a, b) -> int:
    """Git base_name_compare: directories compare as name + '/'."""
    na, da = a[0], a[1]
    nb, db = b[0], b[1]
    n = min(len(na), len(nb))
    if na[:n] != nb[:n]:
        return -1 if na[:n] < nb[:n] else 1
    ca = ord('/') if len(na) == n and da else (0 if len(na) == n else na[n])
    cb = ord('/') if len(nb) == n and db else (0 if len(nb) == n else nb[n])
    return (ca > cb) - (ca < cb)


def git_tree_oid(root: Path, *, omit_root_git: bool = True) -> str:
    """Reproduce a Git tree OID from filesystem bytes, paths and modes."""
    from functools import cmp_to_key

    def walk(path: Path, top: bool) -> bytes:
        entries = []
        with os.scandir(path) as scan:
            for ent in scan:
                if top and omit_root_git and ent.name == '.git':
                    continue
                name = os.fsencode(ent.name)
                p = path / ent.name
                st = ent.stat(follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    oid = walk(p, False)
                    mode = b'40000'
                    is_dir = True
                elif stat.S_ISLNK(st.st_mode):
                    oid = _git_obj_hash(b'blob', os.fsencode(os.readlink(p)))
                    mode = b'120000'
                    is_dir = False
                elif stat.S_ISREG(st.st_mode):
                    oid = _git_obj_hash(b'blob', p.read_bytes())
                    mode = b'100755' if (st.st_mode & 0o111) else b'100644'
                    is_dir = False
                else:
                    raise RuntimeError(f'unsupported filesystem entry: {p}')
                entries.append((name, is_dir, mode, oid))
        entries.sort(key=cmp_to_key(_git_entry_cmp))
        body = b''.join(mode + b' ' + name + b'\0' + oid
                        for name, _is_dir, mode, oid in entries)
        return _git_obj_hash(b'tree', body)

    return walk(root, True).hex()


def ensure_safe_regular(root: Path, rel: str, *, may_be_absent: bool = False) -> Path:
    """Reject symlinked path components for every load-bearing target path."""
    p = root
    parts = Path(rel).parts
    for idx, part in enumerate(parts):
        p = p / part
        if p.exists() or p.is_symlink():
            if p.is_symlink():
                raise RuntimeError(f'{rel}: symlinked component is not accepted: {p}')
            if idx < len(parts) - 1 and not p.is_dir():
                raise RuntimeError(f'{rel}: parent component is not a directory: {p}')
    final = root / rel
    if not final.exists():
        if may_be_absent:
            return final
        raise RuntimeError(f'{rel}: missing')
    if not final.is_file():
        raise RuntimeError(f'{rel}: not a regular file')
    return final


def load_sentinels() -> dict[str, str]:
    out = {}
    for raw in SENTINELS.read_text().splitlines():
        if not raw.strip():
            continue
        digest, rel = raw.split(None, 1)
        rel = rel.strip()
        if not re.fullmatch(r'[0-9a-f]{64}', digest):
            raise RuntimeError(f'bad sentinel digest: {raw}')
        if rel.startswith('/') or '..' in Path(rel).parts:
            raise RuntimeError(f'unsafe sentinel path: {rel}')
        out[rel] = digest
    if len(out) < 4:
        raise RuntimeError('baseline sentinel set is unexpectedly small')
    return out


def verify_delivery() -> None:
    sums = HERE / 'SHA256SUMS'
    if not sums.is_file():
        raise RuntimeError('delivery SHA256SUMS is missing')
    for raw in sums.read_text().splitlines():
        if not raw.strip():
            continue
        digest, rel = raw.split(None, 1)
        rel = rel.strip()
        if rel.startswith('./'):
            rel = rel[2:]
        p = HERE / rel
        if not p.is_file():
            raise RuntimeError(f'delivery file missing: {rel}')
        got = sha256(p)
        if got != digest:
            raise RuntimeError(f'delivery hash mismatch: {rel}: {got} != {digest}')


def tree_state(root: Path) -> list[tuple[str, str, int, str]]:
    """Content/path/mode state; mtimes are intentionally not evidence."""
    out = []
    if not root.is_dir():
        return out
    out.append(('D', '.', stat.S_IMODE(root.stat().st_mode), ''))
    for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs.sort(); files.sort()
        b = Path(base)
        # Record every directory, including empty ones. Symlink directories are
        # recorded as links and never traversed.
        keep = []
        for d in dirs:
            p = b / d
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                out.append(('L', rel, stat.S_IMODE(p.lstat().st_mode), os.readlink(p)))
            else:
                out.append(('D', rel, stat.S_IMODE(p.stat().st_mode), ''))
                keep.append(d)
        dirs[:] = keep
        for name in files:
            p = b / name
            rel = p.relative_to(root).as_posix()
            st = p.lstat()
            mode = stat.S_IMODE(st.st_mode)
            if p.is_symlink():
                out.append(('L', rel, mode, os.readlink(p)))
            elif p.is_file():
                out.append(('F', rel, mode, sha256(p)))
            else:
                out.append(('O', rel, mode, str(st.st_mode)))
    return out


def state_digest(state) -> str:
    payload = json.dumps(state, separators=(',', ':'), ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest()


def snapshot_intended(root: Path) -> dict[str, tuple[bool, str | None, int | None]]:
    snap = {}
    for rel in INTENDED_PATHS:
        p = root / rel
        if p.is_symlink():
            raise RuntimeError(f'{rel}: target is a symlink')
        if p.exists():
            if not p.is_file():
                raise RuntimeError(f'{rel}: target exists but is not a regular file')
            snap[rel] = (True, sha256(p), stat.S_IMODE(p.stat().st_mode))
        else:
            snap[rel] = (False, None, None)
    return snap


def preflight(root: Path) -> dict:
    problems = []
    try:
        verify_delivery()
    except Exception as exc:
        problems.append(str(exc))

    if not root.is_dir():
        problems.append(f'not a directory: {root}')
        return {'problems': problems}
    if (root / '.git').is_file():
        problems.append('.git is a worktree pointer file; staging it safely is not supported')
    try:
        ensure_safe_regular(root, 'docs/REPOSITORY-POLICY.md')
    except Exception as exc:
        problems.append('not a DWC2 research repository root: ' + str(exc))

    # Exact source-tree identity is now available.  This is stronger than the
    # v2.2 compatibility admission: every path, byte, symlink and executable bit
    # outside .git must reconstruct the Git tree bound to SOURCE_COMMIT.
    try:
        got_tree = git_tree_oid(root, omit_root_git=True)
        if got_tree != SOURCE_ROOT_TREE:
            problems.append('source Git tree mismatch: '
                            f'{got_tree} != {SOURCE_ROOT_TREE} '
                            f'(expected commit {SOURCE_COMMIT})')
    except Exception as exc:
        problems.append('source Git tree identity: ' + str(exc))

    # Baseline identity remains pinned independently for defense in depth.
    try:
        for rel, expected in load_sentinels().items():
            p = ensure_safe_regular(root, rel)
            got = sha256(p)
            if got != expected:
                problems.append(f'{rel}: frozen baseline sentinel mismatch: {got} != {expected}')
    except Exception as exc:
        problems.append(str(exc))

    try:
        legacy = ensure_safe_regular(root, REPLACE_SOURCE)
        got = sha256(legacy)
        if got != LEGACY_SHA:
            problems.append(f'{REPLACE_SOURCE} is {got}, not preserved {LEGACY_SHA}; '
                            'already applied or wrong source')
    except Exception as exc:
        problems.append(str(exc))

    for rel in NEW_PATHS:
        try:
            p = ensure_safe_regular(root, rel, may_be_absent=True)
            if p.exists() or p.is_symlink():
                problems.append(f'{rel}: already exists')
            src = FILES / rel
            if not src.is_file():
                problems.append(f'delivery is incomplete: files/{rel} is missing')
        except Exception as exc:
            problems.append(str(exc))

    # The canonical replacement source is a delivery input too.
    if not (FILES / REPLACE_SOURCE).is_file():
        problems.append(f'delivery is incomplete: files/{REPLACE_SOURCE} is missing')

    for name, edits in PATCHES:
        try:
            p = ensure_safe_regular(root, name)
            text = p.read_text()
            for old, _ in edits:
                n = text.count(old)
                if n != 1:
                    problems.append(f'{name}: anchor matched {n} times, wanted 1: '
                                    f'{old.strip()[:60]!r}')
        except Exception as exc:
            problems.append(str(exc))

    try:
        readme = ensure_safe_regular(root, 'r1a-device/README.md')
        got = sha256(readme)
        if got != README_PREIMAGE_SHA:
            problems.append('r1a-device/README.md exact preimage mismatch: '
                            f'{got} != {README_PREIMAGE_SHA}')
        if not (FILES / 'r1a-device/README.md').is_file():
            problems.append('delivery is incomplete: files/r1a-device/README.md is missing')
    except Exception as exc:
        problems.append('r1a-device/README.md preimage: ' + str(exc))

    if problems:
        return {'problems': problems}
    return {
        'problems': [],
        'intended_snapshot': snapshot_intended(root),
        'baseline_state': tree_state(root / 'baseline'),
    }


def apply_edits(root: Path) -> None:
    # New/canonical files. README is an exact-preimage whole-file replacement,
    # not a prose heuristic.
    for rel in [REPLACE_SOURCE, *NEW_PATHS, 'r1a-device/README.md']:
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(FILES / rel, dst)

    for name, edits in PATCHES:
        p = root / name
        text = p.read_text()
        for old, new in edits:
            if text.count(old) != 1:
                raise RuntimeError(f'{name}: staged anchor drift: {old.strip()[:60]!r}')
            text = text.replace(old, new)
        p.write_text(text)



def run_gate(root: Path) -> subprocess.CompletedProcess:
    gate = root / 'VERIFY-REPOSITORY.sh'
    if not gate.is_file():
        return subprocess.CompletedProcess([], 127, '', 'VERIFY-REPOSITORY.sh missing')
    if not os.access(gate, os.X_OK):
        return subprocess.CompletedProcess([], 126, '', 'VERIFY-REPOSITORY.sh is not executable')
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    # Do not allow the repository itself to shadow cc/python/shell helpers.
    env['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    # Execute the gate itself so its shebang, not this applicator, chooses the shell.
    return subprocess.run([str(gate)], cwd=root, env=env,
                          text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT)


def make_stage(root: Path) -> tuple[Path, Path]:
    holder = Path(tempfile.mkdtemp(prefix='.r1a-holder-stage-', dir=root.parent))
    stage = holder / root.name
    try:
        shutil.copytree(root, stage, symlinks=True, copy_function=shutil.copy2)
    except Exception:
        shutil.rmtree(holder, ignore_errors=True)
        raise
    return holder, stage


def verify_snapshot_unchanged(root: Path, snap) -> None:
    now = snapshot_intended(root)
    if now != snap:
        changed = [k for k in snap if snap[k] != now.get(k)]
        raise RuntimeError('target changed after preflight; refusing commit: ' + ', '.join(changed))


def commit_from_stage(root: Path, stage: Path, snap) -> None:
    verify_snapshot_unchanged(root, snap)
    backup = Path(tempfile.mkdtemp(prefix='.r1a-holder-backup-', dir=root.parent))
    committed = []
    try:
        # Prepare backups and replacement temp files before the first rename.
        prepared = []
        for rel in INTENDED_PATHS:
            src = stage / rel
            if not src.is_file():
                raise RuntimeError(f'stage did not produce intended path: {rel}')
            dst = root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if snap[rel][0]:
                b = backup / rel
                b.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, b)
            tmp = dst.with_name(dst.name + f'.r1a-apply-{os.getpid()}.tmp')
            if tmp.exists() or tmp.is_symlink():
                tmp.unlink()
            shutil.copy2(src, tmp)
            prepared.append((rel, src, dst, tmp))

        verify_snapshot_unchanged(root, snap)
        for rel, src, dst, tmp in prepared:
            os.replace(tmp, dst)
            committed.append(rel)

        # Commit proof: every intended path equals the already-gated stage byte-for-byte.
        bad = []
        for rel in INTENDED_PATHS:
            live = root / rel
            staged = stage / rel
            if (sha256(live) != sha256(staged) or
                    stat.S_IMODE(live.stat().st_mode) != stat.S_IMODE(staged.stat().st_mode)):
                bad.append(rel)
        if bad:
            raise RuntimeError('post-commit byte/mode mismatch: ' + ', '.join(bad))
    except Exception:
        # Roll back every intended path, not only the last operation attempted.
        for rel in reversed(INTENDED_PATHS):
            dst = root / rel
            try:
                if snap[rel][0]:
                    b = backup / rel
                    if b.is_file():
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(b, dst)
                else:
                    if dst.exists() or dst.is_symlink():
                        dst.unlink()
            except Exception as rb_exc:
                print(f'ROLLBACK WARNING: {rel}: {rb_exc}', file=sys.stderr)
        raise
    finally:
        for rel in INTENDED_PATHS:
            dst = root / rel
            tmp = dst.with_name(dst.name + f'.r1a-apply-{os.getpid()}.tmp')
            try:
                if tmp.exists() or tmp.is_symlink():
                    tmp.unlink()
            except Exception:
                pass
        shutil.rmtree(backup, ignore_errors=True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('root')
    ap.add_argument('--preflight-only', action='store_true')
    a = ap.parse_args()
    root = Path(a.root).resolve()

    pre = preflight(root)
    if pre['problems']:
        print('REFUSED, nothing was written:')
        for x in pre['problems']:
            print('  ' + x)
        return 1

    baseline_before = pre['baseline_state']
    print('SOURCE_TREE_IDENTITY: PASS')
    print('SOURCE_COMMIT:', SOURCE_COMMIT)
    print('SOURCE_ROOT_TREE:', SOURCE_ROOT_TREE)
    print('SOURCE_BASELINE_TREE:', SOURCE_BASELINE_TREE)
    print('BASELINE_PREIMAGE:', state_digest(baseline_before))
    print('TARGET_PREIMAGE:')
    for rel, (exists, digest, mode) in pre['intended_snapshot'].items():
        print(f'  {rel:<48} ' + (digest if exists else 'ABSENT'))

    holder = stage = None
    try:
        holder, stage = make_stage(root)
        apply_edits(stage)
        gate = run_gate(stage)
        sys.stdout.write(gate.stdout)
        if gate.returncode != 0:
            print(f'PRECOMMIT_GATE: FAIL rc={gate.returncode}')
            print('REFUSED, target tree remains unchanged.')
            return 1

        baseline_after = tree_state(stage / 'baseline')
        if baseline_after != baseline_before:
            print('PRECOMMIT_GATE: FAIL baseline/ changed in staging')
            print('  before:', state_digest(baseline_before))
            print('  after :', state_digest(baseline_after))
            print('REFUSED, target tree remains unchanged.')
            return 1

        print('PRECOMMIT_GATE: PASS')
        print('BASELINE_POSTGATE:', state_digest(baseline_after))
        print('STAGED_OUTPUT:')
        for rel in INTENDED_PATHS:
            print(f'  {rel:<48} {sha256(stage / rel)}')

        # Catch a concurrent edit before deciding whether to commit.
        verify_snapshot_unchanged(root, pre['intended_snapshot'])
        if tree_state(root / 'baseline') != baseline_before:
            raise RuntimeError('baseline/ changed concurrently after preflight')

        if a.preflight_only:
            print('PREFLIGHT_ONLY: PASS — no target bytes written')
            return 0

        commit_from_stage(root, stage, pre['intended_snapshot'])
        if tree_state(root / 'baseline') != baseline_before:
            raise RuntimeError('internal error: baseline/ changed during commit')
        print('COMMIT: PASS')
        print('baseline/ was not touched.')
        print('The committed intended paths are byte-identical to the staged tree '
              'that passed VERIFY-REPOSITORY.sh.')
        return 0
    except Exception as exc:
        print('REFUSED/FAILED:', exc, file=sys.stderr)
        return 1
    finally:
        if holder is not None:
            shutil.rmtree(holder, ignore_errors=True)


if __name__ == '__main__':
    raise SystemExit(main())
