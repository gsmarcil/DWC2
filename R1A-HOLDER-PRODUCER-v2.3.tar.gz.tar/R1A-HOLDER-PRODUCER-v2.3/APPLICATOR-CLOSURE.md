# v2.3 applicator closure

## Source identity

v2.3 is bound to the exact source tree supplied as `DWC2-main (1).zip`.

```text
ZIP SHA256          8d5f81b7927af4296c7ff56a2ff0be37d8b03bea754134ea75f9504caf0cdba7
ZIP comment         9df7b1a4f91a10ef575daa4a658a69ec5ce5723f
source commit       9df7b1a4f91a10ef575daa4a658a69ec5ce5723f
source root tree    d3d13da79d5508d851e995be75e6016c41d3fc42
baseline subtree    223dd3983955393a9cadcbbf525767ce9a49f459
README preimage     69a3149673601cd2aafc050f7eac1363db5dc79f230a18a35b83977c8aaa0b2d
```

The applicator reconstructs the Git tree OID directly from filesystem path,
content, symlink, and executable-bit state. The root `.git` metadata, when
present as a directory, is excluded from this content identity. Any other path
or mode drift fails before staging and before target writes.

This replaces the v2.2 compatibility-only admission. The six frozen baseline
sentinels remain as defense in depth, but they are no longer the source-tree
identity primitive.

## Archive checkout without `.git`

A GitHub source archive omits `.git`. The original repository gate correctly
refused to claim `baseline_pins_tracked` when Git metadata was unavailable.
v2.3 does not turn that failure into an unconditional PASS.

`verify_archive_tracking.py` is executed only as the no-`.git` fallback. It
requires all of the following:

1. `baseline/` reconstructs exactly to Git subtree
   `223dd3983955393a9cadcbbf525767ce9a49f459`;
2. root `.gitignore` has SHA256
   `2745b86f79b61480805798a31337fe10f62cea79bfcd5aa5d8a044064ef2302a`;
3. `baseline/SHA256SUMS` remains well formed and every pinned path exists; and
4. an isolated `git check-ignore --no-index` evaluation says no pinned path is
   ignored by the canonical policy.

If ordinary Git metadata is available, `VERIFY-REPOSITORY.sh` keeps using its
original `git ls-files` / `git check-ignore` branch. The archive proof is a
fallback, not a replacement.

## README provenance

The exact uploaded README is now a hash-pinned preimage. v2.3 performs a
whole-file canonical replacement. The v2.2 paragraph heuristic has been
removed; there is no fuzzy prose match in the commit path.

The replacement states that the active `r1a_ffs_out_v2.c` is new holder-witness
producer source, not a restored original. The legacy pre-holder source remains
preserved by exact SHA256.

## Transaction boundary

No target byte is written before:

```text
SOURCE_TREE_IDENTITY     PASS
exact patch preimages    PASS
private staging          complete
VERIFY-REPOSITORY.sh     PASS in staging
baseline before == after PASS (paths + bytes + modes + symlinks/directories)
live intended preimages  unchanged
live baseline            unchanged
```

`--preflight-only` executes that full path and exits without commit.

Commit writes only the intended paths and then verifies their bytes and modes
against the already-gated staging tree. Process-detected errors attempt rollback
of every intended path. Multi-file atomicity across power loss or kernel crash
is not claimed.

## Scope boundary

These controls prove repository/source admission and fixture/contract behavior.
They do not prove real DWC2 queue depth, endpoint kill timing, or hardware
runtime behavior. Real DWC2 board runtime remains a separate gate.

## Direct-gate self-mutation closure

Independent post-commit replay exposed one additional failure mode: when the
repository gate was invoked directly without the applicator's environment,
Python imports could create `baseline/pipeline/__pycache__/*.pyc`. That changed
the archive Git-tree identity merely by running verification.

v2.3 therefore exports `PYTHONDONTWRITEBYTECODE=1` **inside**
`VERIFY-REPOSITORY.sh` before any Python execution. The transaction self-test
intentionally does not inject that variable when it runs the post-commit gate;
a clean direct invocation must remain read-only by itself.

## Archive proof execution bound

The no-`.git` ignore-policy proof is batched through one
`git check-ignore --no-index -z --stdin` invocation for all 89 pinned paths.
This preserves the exact predicate while avoiding one subprocess per path.
