#!/usr/bin/env python3
"""Rebuild the canonical holder producer from the preserved pre-holder source.

This test is delivery-local: it proves the checked-in build recipe terminates
at exactly files/r1a-device/r1a_ffs_out_v2.c.  It writes only to a temporary
directory and fails closed on any recipe/source/output drift.
"""
from __future__ import annotations

import hashlib
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
LEGACY = ROOT / "files/r1a-device/legacy/r1a_ffs_out_v2.c.pre-holder"
CANON = ROOT / "files/r1a-device/r1a_ffs_out_v2.c"
EXPECTED_LEGACY = "83ea60d3566617eefc0a1b488c2916c0482781b57156d4f0d6116958f126118e"


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def fail(msg: str, cp: subprocess.CompletedProcess[str] | None = None) -> int:
    print("REPRODUCE_SELFTEST: FAIL")
    print("  " + msg)
    if cp is not None:
        if cp.stdout:
            print("  stdout:")
            print("\n".join("    " + x for x in cp.stdout.splitlines()))
        if cp.stderr:
            print("  stderr:")
            print("\n".join("    " + x for x in cp.stderr.splitlines()))
    return 1


def main() -> int:
    if not LEGACY.is_file() or sha(LEGACY) != EXPECTED_LEGACY:
        return fail("preserved legacy source missing or hash drifted")
    if not CANON.is_file():
        return fail("canonical producer is missing")
    scripts = sorted(BUILD.glob("*.py"))
    if not scripts or not (BUILD / "mk_holder.py").is_file():
        return fail("build recipe is incomplete")

    with tempfile.TemporaryDirectory(prefix="r1a-holder-repro-") as td:
        t = Path(td)
        for p in scripts:
            shutil.copyfile(p, t / p.name)
        shutil.copyfile(LEGACY, t / "r1a_ffs_out_v2.c.orig")
        cp = subprocess.run(
            [sys.executable, "mk_holder.py"], cwd=t,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if cp.returncode != 0:
            return fail("mk_holder.py did not complete", cp)
        out = t / "r1a_ffs_out_v2.c"
        if not out.is_file():
            return fail("mk_holder.py produced no source")
        if out.read_bytes() != CANON.read_bytes():
            return fail("regenerated producer is not byte-identical to canonical "
                        f"(generated={sha(out)}, canonical={sha(CANON)})")

    print("REPRODUCE_SELFTEST: PASS")
    print("  legacy_sha256   " + sha(LEGACY))
    print("  canonical_sha256 " + sha(CANON))
    print("  byte_identical  yes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
