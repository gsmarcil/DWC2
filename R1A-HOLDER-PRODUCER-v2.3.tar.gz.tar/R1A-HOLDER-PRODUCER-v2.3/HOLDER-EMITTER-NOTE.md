# Holder emitter note — v2.3

The canonical producer source remains the v2.1/v2.2 admitted source:

```text
SHA256 ab218543d3d0e1baa8777ebcb7c5383ea938c58fc07b2f6cbd6691aca96c6956
```

v2.3 does not change the holder counting semantics. Its change is repository
admission/provenance: exact source-tree binding, exact README preimage, and a
fail-closed archive tracking proof for source archives without `.git`.

Campaign holder records use:

```text
event              R1A_HOLDER
phase              campaign
pending_definition eshutdown_kills_at_or_before_cutoff_excluding_sync_submit_failures
```

Synthetic fixture records use a different namespace:

```text
event      R1A_HOLDER_SELFTEST
phase      selftest
synthetic  true
```

At `--depth 8`, the synthetic holder fixture intentionally produces the lower
bound/control shape:

```text
pending_reads       7
unresolved_reads    1
kills_after_cutoff  1
```

The raw fixture must be refused by `holder_log_guard.py`. The round-trip test
promotes only an explicit test copy into the campaign namespace and sends that
copy through the frozen merger. This proves shape/identity/counting-rule
compatibility only; it is not board evidence.

The remaining load-bearing runtime boundary is unchanged: real DWC2 hardware
has not executed this producer in the campaign path.
